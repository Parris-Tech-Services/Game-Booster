# Neverwinter -- Text Adventure (local run)

Quick steps to run the game locally (no build tools required):

From the project root, run a simple static server. Examples:

Python 3:
```bash
python -m http.server 8000
```

Then open http://localhost:8000 in your browser and click `index.html`.

What I changed to make it run without Tailwind build:
- Added minimal `data/` files (`data/dice.js`, `data/npcs.js`, `data/locations.js`, `data/lore.js`).
- Added a fallback `dist/tailwind.css` with commonly used utility classes so the UI renders.

If you want the full Tailwind styles, install dev dependencies and run:

```bash
npm install
npx tailwindcss -i ./src/input.css -o ./dist/tailwind.css --minify
```

Tell me what you see in the browser console and UI; I'll iterate further (gameplay, quests, combat, polish).
# Neverwinter -- Text Adventure

This project uses ES modules and Tailwind CSS. You must run a local server and build the CSS.

## First-time setup (Tailwind)

```bash
cd neverwinterGame
npm install
npm run build:css
```

For live editing:

```bash
npm run watch:css
```

## Run the game (local server)

### Option A (Python - easiest)

```bash
cd neverwinterGame
python -m http.server 8000
# Open http://localhost:8000
```

### Option B (Node.js)

```bash
npx serve
```

### Option C (VSCode Live Server)

Install the "Live Server" extension, then right-click `index.html` and choose "Open with Live Server".
