export const ENEMIES = [
  {
    id: "goblin",
    name: "Goblin Scavenger",
    hp: 7,
    maxHp: 7,
    ac: 12,
    xp: 25,
    attacks: [
      { name: "Scimitar", bonus: 4, damage: "1d6+2" }
    ],
    drops: { gold: 2, rations: 1 }
  },
  {
    id: "bandit",
    name: "Street Thug",
    hp: 11,
    maxHp: 11,
    ac: 11,
    xp: 50,
    attacks: [
      { name: "Dagger", bonus: 3, damage: "1d4+1" }
    ],
    drops: { gold: 5 }
  },
  {
    id: "wolf",
    name: "Hungry Wolf",
    hp: 11,
    maxHp: 11,
    ac: 13,
    xp: 50,
    attacks: [
      { name: "Bite", bonus: 4, damage: "2d4+2" }
    ],
    drops: { rations: 2 }
  }
];
