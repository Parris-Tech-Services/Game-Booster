export const LORE = {
  "castle-never": [
    { title: "Founding", text: "Legend says the castle was raised from the bones of an old sea giant." }
  ],
  "protectors-enclave": [
    { title: "Watch", text: "The protectors keep a steady eye on comings and goings." }
  ]
};
