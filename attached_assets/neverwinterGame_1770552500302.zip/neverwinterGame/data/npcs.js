export const NPCS = [
  {
    id: "rosene",
    name: "Rosene",
    role: "Innkeeper",
    dialogueTree: {
      start: {
        text: "Rosene smiles as she wipes a mug. \"A warm stew tonight, stranger?\"",
        responses: [
          { text: "Yes, please.", nextNode: "thanks", startQuest: { id: "stew_taste", title: "Taste of the Stew", description: "Try Rosene's stew." } },
          { text: "What's new in town?", nextNode: "gossip" },
          { text: "Not hungry.", nextNode: "goodbye" }
        ]
      },
      gossip: {
        text: "\"Well, there's talk of a broken statue near the market, and the guard Brann's had strange visitors at night.\"",
        responses: [
          { text: "Where is the market?", nextNode: "directions" },
          { text: "I'll look into the statue.", nextNode: "thanks", startQuest: { id: "statue_investigate", title: "Broken Statue", description: "Investigate rumours about the market statue.", reward: { gold: 5 } } }
        ]
      },
      directions: { text: "\"Market Row's east of the Enclave, you'll see the stalls.\"", responses: [] },
      thanks: { text: "\"Here you go. Keep warm, traveler.\"", responses: [] },
      goodbye: { text: "\"Safe journeys.\"", responses: [] }
    }
  },
  {
    id: "brann",
    name: "Brann",
    role: "Guard",
    dialogueTree: {
      start: {
        text: "Brann eyes you, hand near his spear. \"What business do you have in the Enclave?\"",
        responses: [
          { text: "Just passing.", nextNode: "pass" },
          { text: "Looking for work.", nextNode: "work" }
        ]
      },
      pass: { text: "\"Keep to the lanes and mind your step.\"", responses: [] },
      work: { text: "\"The watch could use an extra pair of eyes at night. Report to the barracks.\"", responses: [] }
    }
  }
];

