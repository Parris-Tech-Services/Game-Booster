export class CombatSystem {
  constructor(player, enemy, callbacks) {
    this.player = player;
    this.enemy = JSON.parse(JSON.stringify(enemy)); // Deep copy
    this.callbacks = callbacks; // { onLog: (type, text) => {}, onEnd: (victory) => {} }
    this.turn = 1;
    this.isPlayerTurn = true;
    
    // Initialize combat log
    this.log("combat", `Combat started! ${player.name} vs ${this.enemy.name}`);
  }

  log(type, text) {
    if (this.callbacks.onLog) {
      this.callbacks.onLog(type, text);
    }
  }

  roll(n, sides, bonus = 0) {
    let sum = 0;
    for (let i = 0; i < n; i++) {
      sum += Math.floor(Math.random() * sides) + 1;
    }
    return sum + bonus;
  }

  parseDamage(damageStr) {
    // e.g. "1d6+2"
    const match = damageStr.match(/(\d+)d(\d+)([+-]\d+)?/);
    if (!match) return 0;
    const n = parseInt(match[1]);
    const sides = parseInt(match[2]);
    const bonus = match[3] ? parseInt(match[3]) : 0;
    return this.roll(n, sides, bonus);
  }

  playerAttack() {
    if (!this.isPlayerTurn) return;

    // Simple attack logic for player
    // Assuming player has a basic attack for now, or using str mod
    const attackBonus = Math.floor((this.player.str - 10) / 2) + 2; // Prof bonus +2 approx
    const roll = Math.floor(Math.random() * 20) + 1;
    const total = roll + attackBonus;

    this.log("info", `You attack ${this.enemy.name}... (Rolled ${roll} + ${attackBonus} = ${total} vs AC ${this.enemy.ac})`);

    if (total >= this.enemy.ac) {
      // Hit
      const damage = this.roll(1, 8, Math.floor((this.player.str - 10) / 2)); // Longsword-ish
      this.enemy.hp -= damage;
      this.log("success", `You hit! Dealt ${damage} damage. Enemy HP: ${this.enemy.hp}/${this.enemy.maxHp}`);
      
      if (this.enemy.hp <= 0) {
        this.endCombat(true);
        return;
      }
    } else {
      this.log("info", "You missed.");
    }

    this.isPlayerTurn = false;
    setTimeout(() => this.enemyTurn(), 1000);
  }

  enemyTurn() {
    if (this.enemy.hp <= 0) return;

    const attack = this.enemy.attacks[0];
    const roll = Math.floor(Math.random() * 20) + 1;
    const total = roll + attack.bonus;
    const playerAc = 10 + Math.floor((this.player.dex - 10) / 2); // Simple AC calc

    this.log("combat", `${this.enemy.name} attacks with ${attack.name}... (Rolled ${roll} + ${attack.bonus} = ${total} vs AC ${playerAc})`);

    if (total >= playerAc) {
      const damage = this.parseDamage(attack.damage);
      this.player.hp -= damage;
      this.log("combat", `You are hit! Took ${damage} damage. Your HP: ${this.player.hp}/${this.player.maxHp}`);

      if (this.player.hp <= 0) {
        this.endCombat(false);
        return;
      }
    } else {
      this.log("info", `${this.enemy.name} missed you.`);
    }

    this.turn++;
    this.isPlayerTurn = true;
    this.log("info", `Turn ${this.turn} begins.`);
  }

  flee() {
    // 50% chance to flee
    const roll = Math.random();
    if (roll > 0.5) {
      this.log("info", "You managed to escape!");
      this.callbacks.onEnd(null); // null means fled
    } else {
      this.log("combat", "Failed to escape!");
      this.isPlayerTurn = false;
      setTimeout(() => this.enemyTurn(), 1000);
    }
  }

  endCombat(victory) {
    if (victory) {
      this.log("success", `You defeated ${this.enemy.name}!`);
      if (this.callbacks.onEnd) this.callbacks.onEnd(true, this.enemy);
    } else if (victory === false) {
      this.log("combat", "You have been defeated...");
      if (this.callbacks.onEnd) this.callbacks.onEnd(false, this.enemy);
    }
  }
}
