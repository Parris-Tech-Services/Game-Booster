export const MORE_NPCS = [
  {
    id: "brann",
    name: "Brann",
    role: "Guard",
    dialogueTree: {
      start: {
        text: "Halt. State your business.",
        responses: [
          { text: "Just passing.", nextNode: "pass" },
          { text: "On official duty.", nextNode: "duty" }
        ]
      },
      pass: { text: "Move along then.", responses: [] },
      duty: { text: "Carry on, then.", responses: [] }
    }
  }
];
