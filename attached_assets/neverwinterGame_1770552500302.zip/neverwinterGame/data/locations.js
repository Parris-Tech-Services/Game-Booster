// Grid-based locations for a small explorable Neverwinter map (x,y coordinates)
export const LOCATIONS = [
  { id: "castle-never", name: "Castle Never", x: 2, y: 1, description: "The grand keep towers over the docks. Smoke drifts.", ambience: "Cool sea breeze mixed with smoke and ale.", npcs: ["rosene"] },
  { id: "protectors-enclave", name: "Protector's Enclave", x: 2, y: 2, description: "Worn cobblestones and watchful guards.", ambience: "Guards patrol, voices carry.", npcs: ["brann"] },
  { id: "docks", name: "The Docks", x: 2, y: 0, description: "Ropes creak and gulls cry above busy piers.", ambience: "Salt and tar.", npcs: [] },
  { id: "market", name: "Market Row", x: 3, y: 2, description: "Stalls spill over with wares and gossip.", ambience: "Haggling voices and scents of spices.", npcs: [] },
  { id: "blacklake", name: "Blacklake District", x: 4, y: 2, description: "Narrow alleys and lamplit windows.", ambience: "Distant laughter and clinking glass.", npcs: [] },
  { id: "beached-leviathan", name: "Beached Leviathan", x: 1, y: 3, description: "A massive ribcage juts from the sand.", ambience: "The sea whispers through bone.", npcs: [] },
  { id: "the-chasm", name: "The Chasm", x: 2, y: 4, description: "A yawning fissure cuts the earth open.", ambience: "Cold drafts rise from below.", npcs: [] },
  { id: "north-gate", name: "North Gate", x: 2, y: -1, description: "A heavy gate marks the road north.", ambience: "Horse hooves, distant road noise.", npcs: [] },
  { id: "east-ward", name: "East Ward", x: 4, y: 1, description: "Quiet residential lanes and tidy gardens.", ambience: "Chatter from shutters.", npcs: [] },
  { id: "westward", name: "Westward Lane", x: 0, y: 2, description: "A narrow lane leading to old docks and warehouses.", ambience: "Faint creaks and the smell of oil.", npcs: [] }
];

