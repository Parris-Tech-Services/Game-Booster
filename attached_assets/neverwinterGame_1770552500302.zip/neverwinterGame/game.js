const { createApp } = Vue;

export const app = createApp({
  data() {
    return {
      player: {
        name: "Adventurer",
        level: 1,
        xp: 0,
        nextLevelXp: 300,
        str: 14,
        dex: 12,
        con: 13,
        int: 13,
        wis: 11,
        cha: 12,
        hp: 11,
        maxHp: 11,
        ac: 10,
        equipped: {
          weapon: { name: "Rusty Dagger", damage: "1d4", type: "piercing" },
          armor: { name: "Leather Armor", ac: 11, type: "light" }
        },
        abilities: []
      },
      inventory: [
        { name: "Worn Cloak", type: "clothing", value: 5 },
        { name: "Traveler's Rations", type: "consumable", value: 5 },
        { name: "Health Potion", type: "consumable", effect: { type: "heal", amount: "2d4+2" }, value: 50 }
      ],
      resources: {
        rations: 5,
        gold: 10,
        fatigue: 0,
      },
      combat: {
        inCombat: false,
        currentEnemy: null,
        turn: 'player',
        round: 0,
        log: []
      },
      enemies: {
        goblin: {
          name: 'Goblin',
          level: 1,
          hp: 7,
          maxHp: 7,
          ac: 15,
          attack: '+4',
          damage: '1d6+2',
          xp: 50,
          gold: '1d6',
          loot: [
            { name: 'Rusty Dagger', chance: 0.6 },
            { name: 'Health Potion', chance: 0.2 }
          ]
        },
        bandit: {
          name: 'Bandit',
          level: 2,
          hp: 11,
          maxHp: 11,
          ac: 12,
          attack: '+3',
          damage: '1d6+1',
          xp: 100,
          gold: '2d6',
          loot: [
            { name: 'Shortsword', chance: 0.7 },
            { name: 'Leather Armor', chance: 0.4 },
            { name: 'Health Potion', chance: 0.3 }
          ]
        }
      },
      time: {
        day: 1,
        hour: 18,
      },
      gameLog: [
        {
          type: "narrative",
          text: "You arrive in Neverwinter as the city settles into twilight.",
        },
      ],
      currentLocationId: null,
      currentDialogue: { npcId: null, nodeId: null },
      travelPreview: null,
      saveText: "",
      userInput: "",
      showMap: true,
      showHelp: false,
      settings: {
        uiScale: 1.0,
        textSize: 16,
        showTimestamps: false,
        compactLog: false,
      },
      quests: {},
    };
  },
  computed: {
    strMod() {
      return Math.floor((this.player.str - 10) / 2);
    },
    dexMod() {
      return Math.floor((this.player.dex - 10) / 2);
    },
    conMod() {
      return Math.floor((this.player.con - 10) / 2);
    },
    intMod() {
      return Math.floor((this.player.int - 10) / 2);
    },
    wisMod() {
      return Math.floor((this.player.wis - 10) / 2);
    },
    chaMod() {
      return Math.floor((this.player.cha - 10) / 2);
    },
    armorClass() {
      return 10 + this.dexMod;
    },
    locations() {
      const src = this.$locations || window.LOCATIONS || [];
      if (Array.isArray(src)) return src;
      // allow keyed object (id -> location) as well
      if (src && typeof src === 'object') return Object.values(src);
      return [];
    },
    npcs() {
      const src = this.$npcs || window.NPCS || [];
      if (Array.isArray(src)) return src;
      if (src && typeof src === 'object') return Object.values(src);
      return [];
    },
    lore() {
      return this.$lore || window.LORE || {};
    },
    currentLocation() {
      return this.locations.find((l) => l.id === this.currentLocationId) || this.locations[0] || null;
    },
    npcsInLocation() {
      if (!this.currentLocation) return [];
      const npcIds = Array.isArray(this.currentLocation.npcs) ? this.currentLocation.npcs : [];
      return this.npcs.filter((n) => npcIds.includes(n.id));
    },
    currentNPC() {
      if (!this.currentDialogue.npcId) return null;
      return this.npcs.find((n) => n.id === this.currentDialogue.npcId) || null;
    },
    currentNode() {
      if (!this.currentNPC || !this.currentDialogue.nodeId) return null;
      if (!this.currentNPC.dialogueTree) return null;
      return this.currentNPC.dialogueTree[this.currentDialogue.nodeId] || null;
    },
    dialogueResponses() {
      return this.currentNode && Array.isArray(this.currentNode.responses) ? this.currentNode.responses : [];
    },
    timeLabel() {
      const hour = this.time.hour % 12 || 12;
      const ampm = this.time.hour >= 12 ? 'PM' : 'AM';
      let timeOfDay = '';
      if (this.time.hour < 6) timeOfDay = ' (Late Night)';
      else if (this.time.hour < 12) timeOfDay = ' (Morning)';
      else if (this.time.hour < 18) timeOfDay = ' (Afternoon)';
      else timeOfDay = ' (Evening)';
      return `Day ${this.time.day}, ${hour}${ampm}${timeOfDay}`;
    },
    playerAc() {
      return this.player.ac + this.dexMod;
    },
    proficiencyBonus() {
      return Math.floor((this.player.level - 1) / 4) + 2;
    },
    attackBonus() {
      return this.strMod + this.proficiencyBonus;
    },
    damageBonus() {
      return this.strMod;
    },
    mapAscii() {
      const loc = this.currentLocationId || "unknown";
      const mark = (id, label) => (loc === id ? `*${label}*` : ` ${label} `);
      return [
        "                 [Castle Never]",
        "                       |",
        "                       |",
        "               [Protector's Enclave]",
        "                 /             \\",
        "                /               \\",
        `     ${mark("beached-leviathan", "Beached Leviathan")}     ${mark("blacklake", "Blacklake District")}`,
        "                \\               /",
        "                 \\             /",
        "                    [The Chasm]",
      ].join("\n");
    },
    // Grid map helpers
    mapBounds() {
      if (!this.locations.length) return { minX: 0, maxX: 4, minY: 0, maxY: 4 };
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (const l of this.locations) {
        if (typeof l.x === 'number' && typeof l.y === 'number') {
          minX = Math.min(minX, l.x);
          minY = Math.min(minY, l.y);
          maxX = Math.max(maxX, l.x);
          maxY = Math.max(maxY, l.y);
        }
      }
      if (minX === Infinity) return { minX: 0, maxX: 4, minY: 0, maxY: 4 };
      return { minX, maxX, minY, maxY };
    },
    mapGrid() {
      const b = this.mapBounds;
      const rows = [];
      for (let y = b.minY; y <= b.maxY; y++) {
        const row = [];
        for (let x = b.minX; x <= b.maxX; x++) {
          const loc = this.locations.find((l) => l.x === x && l.y === y) || null;
          row.push({ x, y, loc });
        }
        rows.push(row);
      }
      return rows;
    },
    mapGridCols() {
      if (!this.mapGrid || !this.mapGrid[0]) return 0;
      return this.mapGrid[0].length;
    },
    mapGridFlat() {
      return this.mapGrid.flat().map(c => ({ key: `${c.x},${c.y}`, x: c.x, y: c.y, loc: c.loc }));
    },
    adjacentRoutes() {
      const routes = this.normalizedRoutes();
      return routes.map((route) => {
        const dest = this.locations.find((l) => l.id === route.to);
        return { route: route, destination: dest };
      });
    },
  },
  methods: {
    isAdjacentCoords(x, y) {
      const currentLoc = this.locations.find(l => l.id === this.currentLocationId);
      if (!currentLoc) return false;
      
      // Check if coordinates are adjacent (including diagonals)
      return Math.abs(currentLoc.x - x) <= 1 && Math.abs(currentLoc.y - y) <= 1;
    },
    
    clickMap(x, y) {
      const loc = this.locations.find(l => l.x === x && l.y === y);
      if (!loc) return;
      
      // If it's the current location, just update the preview
      if (loc.id === this.currentLocationId) {
        this.clearPreview();
        return;
      }
      
      // Check if it's directly adjacent
      const currentLoc = this.locations.find(l => l.id === this.currentLocationId);
      if (currentLoc && this.isAdjacentCoords(x, y)) {
        const route = this.normalizedRoutes().find(r => r.to === loc.id);
        if (route) {
          this.previewRoute(route.to);
        }
      } else {
        // Show location info
        this.append('info', `${loc.name}: ${loc.description || 'No description available.'}`);
      }
    },
    // Combat methods
    startCombat(enemyType) {
      this.combat.inCombat = true;
      this.combat.currentEnemy = JSON.parse(JSON.stringify(this.enemies[enemyType]));
      this.combat.turn = 'player';
      this.combat.round = 1;
      this.combat.log = [];
      this.append('combat', `A wild ${this.combat.currentEnemy.name} appears!`);
      this.append('combat', `You draw your ${this.player.equipped.weapon.name} and prepare for battle!`);
    },

    async playerAttack() {
      if (!this.combat.inCombat) return;
      
      this.append('combat', `You attack the ${this.combat.currentEnemy.name} with your ${this.player.equipped.weapon.name}!`);
      
      // Simulate attack roll (d20 + attack bonus)
      const attackRoll = rollDice('1d20') + this.attackBonus();
      
      if (attackRoll >= this.combat.currentEnemy.ac) {
        // Hit!
        const damage = rollDice(this.player.equipped.weapon.damage) + this.damageBonus();
        this.combat.currentEnemy.hp -= damage;
        this.append('combat', `You hit for ${damage} damage!`);
        
        // Check if enemy is defeated
        if (this.combat.currentEnemy.hp <= 0) {
          await this.defeatEnemy();
          return;
        }
      } else {
        this.append('combat', 'Your attack misses!');
      }
      
      // Enemy's turn
      this.combat.turn = 'enemy';
      setTimeout(() => this.enemyTurn(), 1000);
    },
    
    async enemyTurn() {
      if (!this.combat.inCombat) return;
      
      this.append('combat', `The ${this.combat.currentEnemy.name} attacks you!`);
      
      // Simulate enemy attack roll
      const attackRoll = rollDice('1d20') + parseInt(this.combat.currentEnemy.attack);
      
      if (attackRoll >= this.playerAc) {
        // Enemy hits
        const damage = rollDice(this.combat.currentEnemy.damage);
        this.player.hp -= damage;
        this.append('combat', `The ${this.combat.currentEnemy.name} hits you for ${damage} damage!`);
        
        // Check if player is defeated
        if (this.player.hp <= 0) {
          this.player.hp = 0;
          this.append('combat', 'You have been defeated! Game over.');
          this.combat.inCombat = false;
          return;
        }
      } else {
        this.append('combat', `The ${this.combat.currentEnemy.name} misses!`);
      }
      
      // Next round
      this.combat.turn = 'player';
      this.combat.round++;
    },
    
    async defeatEnemy() {
      const enemy = this.combat.currentEnemy;
      const xpGained = enemy.xp;
      const goldGained = rollDice(enemy.gold);
      
      this.player.xp += xpGained;
      this.resources.gold += goldGained;
      
      this.append('success', `You defeated the ${enemy.name}!`);
      this.append('success', `Gained ${xpGained} XP and found ${goldGained} gold!`);
      
      // Check for level up
      if (this.player.xp >= this.player.nextLevelXp) {
        this.levelUp();
      }
      
      // Chance to drop loot
      if (enemy.loot) {
        enemy.loot.forEach(item => {
          if (Math.random() < item.chance) {
            const lootItem = this.createItem(item.name);
            this.inventory.push(lootItem);
            this.append('success', `Found ${lootItem.name}!`);
          }
        });
      }
      
      // End combat
      this.combat.inCombat = false;
      this.combat.currentEnemy = null;
    },
    
    levelUp() {
      this.player.level++;
      this.player.maxHp += 5 + this.conMod;
      this.player.hp = this.player.maxHp;
      this.player.nextLevelXp = Math.floor(this.player.nextLevelXp * 1.5);
      
      this.append('info', `Level up! You are now level ${this.player.level}!`);
      this.append('info', `Your maximum HP is now ${this.player.maxHp}.`);
      
      // Grant new abilities at certain levels
      if (this.player.level === 2) {
        this.player.abilities.push('Second Wind');
        this.append('info', 'You gained a new ability: Second Wind! (Use "second wind" in combat to heal 1d10 + your level)');
      }
    },
    
    useItem(itemName) {
      const itemIndex = this.inventory.findIndex(item => item.name.toLowerCase() === itemName.toLowerCase());
      
      if (itemIndex === -1) {
        this.append('info', `You don't have ${itemName} in your inventory.`);
        return false;
      }
      
      const item = this.inventory[itemIndex];
      
      if (item.type === 'consumable' && item.effect) {
        if (item.effect.type === 'heal') {
          const healAmount = rollDice(item.effect.amount);
          this.player.hp = Math.min(this.player.hp + healAmount, this.player.maxHp);
          this.append('success', `You drink the ${item.name} and heal for ${healAmount} HP!`);
        }
        
        // Remove the item if it's a consumable
        this.inventory.splice(itemIndex, 1);
        return true;
      }
      
      this.append('info', `You can't use ${item.name} right now.`);
      return false;
    },
    
    createItem(itemName) {
      // Simple item creation - expand this for more items
      const items = {
        'Health Potion': { name: 'Health Potion', type: 'consumable', effect: { type: 'heal', amount: '2d4+2' }, value: 50 },
        'Rusty Dagger': { name: 'Rusty Dagger', type: 'weapon', damage: '1d4', value: 10 },
        'Shortsword': { name: 'Shortsword', type: 'weapon', damage: '1d6', value: 100 },
        'Leather Armor': { name: 'Leather Armor', type: 'armor', ac: 11, value: 100 }
      };
      
      return items[itemName] || { name: itemName, type: 'misc', value: 10 };
    },
    
    equipItem(itemName) {
      const itemIndex = this.inventory.findIndex(item => item.name.toLowerCase() === itemName.toLowerCase());
      
      if (itemIndex === -1) {
        this.append('info', `You don't have ${itemName} in your inventory.`);
        return;
      }
      
      const item = this.inventory[itemIndex];
      
      if (item.type === 'weapon') {
        // Move current weapon to inventory
        this.inventory.push({...this.player.equipped.weapon});
        this.player.equipped.weapon = {...item};
        this.inventory.splice(itemIndex, 1);
        this.append('success', `You equip the ${item.name}.`);
      } else if (item.type === 'armor') {
        // Move current armor to inventory
        this.inventory.push({...this.player.equipped.armor});
        this.player.equipped.armor = {...item};
        this.inventory.splice(itemIndex, 1);
        this.player.ac = item.ac;
        this.append('success', `You equip the ${item.name}.`);
      } else {
        this.append('info', `You can't equip ${item.name}.`);
      }
    },
    
    rest() {
      if (this.combat.inCombat) {
        this.append('info', 'You cannot rest while in combat!');
        return;
      }
      
      // Heal half of max HP, minimum 1
      const healAmount = Math.max(1, Math.floor(this.player.maxHp / 2));
      this.player.hp = Math.min(this.player.hp + healAmount, this.player.maxHp);
      
      // Advance time by 8 hours
      this.advanceTime(8);
      
      this.append('success', `You rest and recover ${healAmount} HP.`);
      this.append('info', 'The time is now ' + this.timeLabel);
    },
    
    // Enhanced command handling
    processCommand(cmd) {
      const parts = cmd.toLowerCase().split(' ');
      const action = parts[0];
      const target = parts.slice(1).join(' ');
      
      if (this.combat.inCombat) {
        // Combat commands
        switch(action) {
          case 'attack':
            this.playerAttack();
            return true;
          case 'use':
            return this.useItem(target);
          case 'flee':
            // 50% chance to flee successfully
            if (Math.random() < 0.5) {
              this.append('info', 'You successfully flee from combat!');
              this.combat.inCombat = false;
              this.combat.currentEnemy = null;
            } else {
              this.append('info', 'You try to flee but fail!');
              this.combat.turn = 'enemy';
              setTimeout(() => this.enemyTurn(), 1000);
            }
            return true;
          case 'second':
            if (parts[1] === 'wind' && this.player.abilities.includes('Second Wind')) {
              const healAmount = rollDice('1d10') + this.player.level;
              this.player.hp = Math.min(this.player.hp + healAmount, this.player.maxHp);
              this.append('success', `You use Second Wind and recover ${healAmount} HP!`);
              this.combat.turn = 'enemy';
              setTimeout(() => this.enemyTurn(), 1000);
              return true;
            }
            break;
        }
      }
      
      // Non-combat commands
      switch(action) {
        case 'rest':
          this.rest();
          return true;
        case 'heal':
        case 'drink':
        case 'use':
          return this.useItem(target);
        case 'equip':
          this.equipItem(target);
          return true;
        case 'inspect':
          this.inspect(target);
          return true;
        case 'attack':
          // Check if there's an enemy to attack
          if (this.currentLocation && this.currentLocation.enemies && this.currentLocation.enemies.length > 0) {
            const enemyToFight = this.currentLocation.enemies[0]; // Attack first enemy in location
            this.startCombat(enemyToFight);
            return true;
          } else {
            this.append('info', 'There is nothing to attack here.');
            return true;
          }
      }
      
      return false; // Command not handled
    },
    normalizedRoutes() {
      if (!this.currentLocation) return [];
      if (Array.isArray(this.currentLocation.paths) && this.currentLocation.paths.length) {
        return this.currentLocation.paths;
      }
      if (Array.isArray(this.currentLocation.exits) && this.currentLocation.exits.length) {
        return this.currentLocation.exits.map((id) => ({
          to: id,
          distance: 1,
          hours: 1,
          cost: { rations: 1, gold: 0 },
          encounterChance: 0.05,
        }));
      }
      // If current location has coordinates, auto-generate neighbor routes (N/S/E/W)
      if (typeof this.currentLocation.x === 'number' && typeof this.currentLocation.y === 'number') {
        const routes = [];
        const dirs = [ {dx:0,dy:-1},{dx:0,dy:1},{dx:1,dy:0},{dx:-1,dy:0} ];
        for (const d of dirs) {
          const nx = this.currentLocation.x + d.dx;
          const ny = this.currentLocation.y + d.dy;
          const neighbor = this.locations.find((l) => l.x === nx && l.y === ny);
          if (neighbor) {
            routes.push({ to: neighbor.id, distance: 1, hours: 1, cost: { rations: 1, gold: 0 }, encounterChance: 0.03 });
          }
        }
        return routes;
      }
      return [];
    },
    append(type, text) {
      const entry = { type: type, text: text };
      if (this.settings && this.settings.showTimestamps) {
        entry.time = new Date().toLocaleTimeString();
      }
      this.gameLog.push(entry);
      this.$nextTick(() => {
        if (this.$refs.log) {
          this.$refs.log.scrollTop = this.$refs.log.scrollHeight;
        }
      });
    },
    describeLocation() {
      if (!this.currentLocation) return;
      this.append("narrative", this.currentLocation.description);
      if (this.currentLocation.ambience) {
        this.append("info", `Ambience: ${this.currentLocation.ambience}`);
      }
      var loreForLoc = this.lore[this.currentLocation.id];
      if (loreForLoc && loreForLoc.length) {
        var pick = loreForLoc[Math.floor(Math.random() * loreForLoc.length)];
        this.append("lore", `Lore -- ${pick.title}: ${pick.text}`);
      }
    },
    getRouteTo(locationId) {
      const routes = this.normalizedRoutes();
      return routes.find((p) => p.to === locationId) || null;
    },
    previewRoute(locationId) {
      const route = this.getRouteTo(locationId);
      if (!route) {
        this.append("info", "That destination is not directly connected.");
        return;
      }
      this.travelPreview = { route: route, destinationId: route.to };
    },
    clearPreview() {
      this.travelPreview = null;
    },
    advanceTime(hours) {
      let total = this.time.hour + hours;
      while (total >= 24) {
        total -= 24;
        this.time.day += 1;
      }
      this.time.hour = total;
    },
    isMarketOpen() {
      const hour = this.time.hour % 24;
      return hour >= 7 && hour < 20;
    },
    executeTravel(route) {
      const dest = this.locations.find((l) => l.id === route.to);
      if (!dest) return;
      const cost = route.cost || {};
      if (cost.rations && this.resources.rations < cost.rations) {
        // try to use a physical ration item from inventory (e.g., "Traveler's rations")
        const idx = this.inventory.findIndex((it) => typeof it === 'string' ? it.toLowerCase().includes('ration') : (it.name && it.name.toLowerCase().includes('ration')));
        if (idx !== -1) {
          const used = this.inventory.splice(idx, 1)[0];
          this.append('info', `You use ${typeof used === 'string' ? used : used.name} for the journey.`);
          // allow travel (do not deduct resources.rations further)
        } else {
          this.append("info", "You need more rations before traveling.");
          return;
        }
      }
      if (cost.gold && this.resources.gold < cost.gold) {
        this.append("info", "You do not have enough gold for that journey.");
        return;
      }

      if (cost.rations) this.resources.rations -= cost.rations;
      if (cost.gold) this.resources.gold -= cost.gold;

      this.advanceTime(route.hours || 1);
      this.append("info", `Time passes: ${this.timeLabel}`);

      if (route.encounterChance && Math.random() < route.encounterChance) {
        this.append("combat", "A sudden encounter interrupts your travel. (Encounter system placeholder)");
      }

      this.currentLocationId = dest.id;
      this.currentDialogue = { npcId: null, nodeId: null };
      this.append("narrative", `You travel to ${dest.name}.`);
      this.describeLocation();
      this.travelPreview = null;
      return true;
    },

    // Build adjacency list for any given location id
    normalizedRoutesFor(locationId) {
      const loc = this.locations.find((l) => l.id === locationId);
      if (!loc) return [];
      if (Array.isArray(loc.paths) && loc.paths.length) return loc.paths;
      if (Array.isArray(loc.exits) && loc.exits.length) {
        return loc.exits.map((id) => ({
          to: id,
          distance: 1,
          hours: 1,
          cost: { rations: 1, gold: 0 },
          encounterChance: 0.05,
        }));
      }
      // If the location has coordinates, generate neighbor routes
      if (typeof loc.x === 'number' && typeof loc.y === 'number') {
        const routes = [];
        const dirs = [ {dx:0,dy:-1},{dx:0,dy:1},{dx:1,dy:0},{dx:-1,dy:0} ];
        for (const d of dirs) {
          const nx = loc.x + d.dx;
          const ny = loc.y + d.dy;
          const neighbor = this.locations.find((l) => l.x === nx && l.y === ny);
          if (neighbor) {
            routes.push({ to: neighbor.id, distance: 1, hours: 1, cost: { rations: 1, gold: 0 }, encounterChance: 0.03 });
          }
        }
        return routes;
      }
      return [];
    },

    getLocationByCoords(x,y) {
      return this.locations.find((l) => l.x === x && l.y === y) || null;
    },

    isAdjacentCoords(x,y) {
      if (!this.currentLocation) return false;
      const dx = Math.abs((this.currentLocation.x || 0) - x);
      const dy = Math.abs((this.currentLocation.y || 0) - y);
      return dx + dy === 1;
    },

    moveDirection(dir) {
      if (!this.currentLocation || typeof this.currentLocation.x !== 'number') {
        this.append('info','No lat/long data for current location.');
        return;
      }
      const dmap = { n: {dx:0,dy:-1}, north: {dx:0,dy:-1}, s: {dx:0,dy:1}, south: {dx:0,dy:1}, e: {dx:1,dy:0}, east: {dx:1,dy:0}, w: {dx:-1,dy:0}, west: {dx:-1,dy:0} };
      const d = dmap[dir.toLowerCase()];
      if (!d) return;
      const nx = this.currentLocation.x + d.dx;
      const ny = this.currentLocation.y + d.dy;
      const neighbor = this.getLocationByCoords(nx,ny);
      if (!neighbor) {
        this.append('info', "You can't go that way.");
        return;
      }
      const route = { to: neighbor.id, hours: 1, cost: { rations: 1, gold: 0 }, encounterChance: 0.03 };
      this.executeTravel(route);
    },

    eat(itemName) {
      const name = (itemName || '').toLowerCase();
      if (this.resources.rations > 0) {
        this.resources.rations -= 1;
        this.append('info', 'You eat a ration.');
        return true;
      }
      // try to find a ration in inventory
      const idx = this.inventory.findIndex((it) => (typeof it === 'string' ? it.toLowerCase() : (it.name||'').toLowerCase()).includes('ration'));
      if (idx !== -1) {
        const used = this.inventory.splice(idx,1)[0];
        // eating this gives you sustenance but also consumes it
        this.append('info', `You eat ${typeof used === 'string' ? used : used.name}.`);
        return true;
      }
      this.append('info', 'You have nothing to eat.');
      return false;
    },

    clickMap(x,y) {
      const loc = this.getLocationByCoords(x,y);
      if (!loc) {
        this.append('info','There is nothing of interest there.');
        return;
      }
      if (this.isAdjacentCoords(x,y)) {
        this.moveDirection((this.currentLocation.x - x) === 1 ? 'w' : (x - this.currentLocation.x) === 1 ? 'e' : (this.currentLocation.y - y) === 1 ? 'n' : 's');
        return;
      }
      // not adjacent: plan route
      this.planRoute(loc.id);
    },

    // Dijkstra by hours to find ordered legs from sourceId to destId
    findPath(sourceId, destId) {
      if (sourceId === destId) return [];
      const nodes = this.locations.map((l) => l.id);
      const dist = {};
      const prev = {};
      const prevRoute = {};
      nodes.forEach((n) => (dist[n] = Infinity));
      if (!dist.hasOwnProperty(sourceId) || !dist.hasOwnProperty(destId)) return null;
      dist[sourceId] = 0;

      const unvisited = new Set(nodes);
      while (unvisited.size) {
        // pick node with smallest dist
        let u = null;
        let best = Infinity;
        for (const id of unvisited) {
          if (dist[id] < best) {
            best = dist[id];
            u = id;
          }
        }
        if (u === null) break;
        unvisited.delete(u);
        if (u === destId) break;

        const routes = this.normalizedRoutesFor(u);
        for (const r of routes) {
          const v = r.to;
          if (!unvisited.has(v)) continue;
          const alt = dist[u] + (r.hours || 1);
          if (alt < dist[v]) {
            dist[v] = alt;
            prev[v] = u;
            prevRoute[v] = r;
          }
        }
      }

      if (dist[destId] === Infinity) return null;
      // reconstruct path
      const legs = [];
      let cur = destId;
      while (cur !== sourceId) {
        const route = prevRoute[cur];
        if (!route) break;
        legs.push(route);
        cur = prev[cur];
      }
      return legs.reverse();
    },

    // Plan a route from current location to destId (may be multi-hop)
    planRoute(destId) {
      if (!this.currentLocation) {
        this.append("info", "No current location to plan from.");
        return;
      }
      const legs = this.findPath(this.currentLocation.id, destId);
      if (!legs) {
        this.append("info", "No route found to that destination.");
        return;
      }
      // compute totals
      let totalHours = 0;
      const totalCost = { rations: 0, gold: 0 };
      const encounterList = [];
      const waypointIds = [this.currentLocation.id];
      for (const leg of legs) {
        totalHours += leg.hours || 1;
        if (leg.cost) {
          totalCost.rations += leg.cost.rations || 0;
          totalCost.gold += leg.cost.gold || 0;
        }
        encounterList.push(leg.encounterChance || 0);
        waypointIds.push(leg.to);
      }
      const combinedEncounter = 1 - encounterList.reduce((acc, p) => acc * (1 - p), 1);
      const waypoints = waypointIds.map((id) => (this.locations.find((l) => l.id === id) || {}).name || id);
      this.travelPreview = {
        planned: true,
        legs: legs,
        totalHours,
        totalCost,
        combinedEncounter,
        waypoints,
        destinationId: destId,
      };
      this.append("info", `Planned route to ${(this.locations.find(l => l.id === destId) || {}).name || destId}: ${waypoints.join(" -> ")}`);
      this.append("info", `Total: ${totalHours}h, cost: ${totalCost.rations} rations, ${totalCost.gold} gp, combined encounter ${(Math.round(combinedEncounter*100))}%`);
    },

    // Execute a planned route (per-leg execution). Aborts if a leg fails.
    executePlannedRoute() {
      if (!this.travelPreview || !this.travelPreview.planned) return;
      for (const leg of this.travelPreview.legs) {
        const ok = this.executeTravel(leg);
        if (!ok) {
          this.append("info", "Planned route aborted.");
          return;
        }
        // small pause could be added later for narrative
      }
      this.travelPreview = null;
    },
    increaseScale() {
      // kept for backward compatibility; redirect to text size change
      this.increaseTextSize();
    },
    decreaseScale() {
      // kept for backward compatibility; redirect to text size change
      this.decreaseTextSize();
    },
    increaseTextSize() {
      this.settings.textSize = Math.min(28, this.settings.textSize + 1);
      this.saveSettings();
    },
    decreaseTextSize() {
      this.settings.textSize = Math.max(10, this.settings.textSize - 1);
      this.saveSettings();
    },
    toggleTimestamps() {
      this.settings.showTimestamps = !this.settings.showTimestamps;
      this.saveSettings();
    },
    toggleCompact() {
      this.settings.compactLog = !this.settings.compactLog;
      this.saveSettings();
    },
    saveSettings() {
      try {
        localStorage.setItem("neverwinter_settings", JSON.stringify(this.settings));
      } catch (e) {
        console.warn("Could not save settings", e);
      }
    },
    loadSettings() {
      try {
        const raw = localStorage.getItem("neverwinter_settings");
        if (!raw) return;
        const s = JSON.parse(raw);
        if (s && typeof s === "object") {
          this.settings = Object.assign(this.settings || {}, s);
        }
      } catch (e) {
        console.warn("Could not load settings", e);
      }
    },
    // Quest persistence and management
    saveQuests() {
      try {
        localStorage.setItem("neverwinter_quests", JSON.stringify(this.quests || {}));
      } catch (e) {
        console.warn("Could not save quests", e);
      }
    },
    loadQuests() {
      try {
        const raw = localStorage.getItem("neverwinter_quests");
        if (!raw) return;
        const q = JSON.parse(raw);
        if (q && typeof q === "object") this.quests = q;
      } catch (e) {
        console.warn("Could not load quests", e);
      }
    },
    startQuest(q) {
      if (!q || !q.id) return;
      if (this.quests[q.id] && this.quests[q.id].status === "active") {
        this.append("info", `Quest '${q.title || q.id}' is already active.`);
        return;
      }
      this.quests[q.id] = Object.assign({ status: "active", startedAt: Date.now() }, q);
      this.append("success", `Quest started: ${q.title || q.id}`);
      this.saveQuests();
    },
    completeQuest(questId) {
      const q = this.quests[questId];
      if (!q || q.status !== "active") {
        this.append("info", "No active quest with that id.");
        return;
      }
      q.status = "completed";
      q.completedAt = Date.now();
      this.append("success", `Quest completed: ${q.title || questId}. Reward applied.`);
      if (q.reward && q.reward.gold) this.resources.gold += q.reward.gold;
      this.saveQuests();
    },
    travel(locationId) {
      const route = this.getRouteTo(locationId);
      if (!route) {
        this.append("info", "That destination is not directly connected. Use the map to see routes.");
        return;
      }
      this.executeTravel(route);
    },
    startDialogue(npcId) {
      var npc = this.npcs.find((n) => n.id === npcId);
      if (!npc) return;
      if (!npc.dialogueTree || !npc.dialogueTree.start) {
        this.append("info", `${npc.name} has nothing to say right now.`);
        return;
      }
      this.currentDialogue = { npcId: npc.id, nodeId: "start" };
      this.append("narrative", `${npc.name} (${npc.role}) turns to you.`);
      this.append("narrative", npc.dialogueTree.start.text);
    },
    chooseResponse(index) {
      if (!this.currentNode || !this.currentNPC) return;
      var resp = this.currentNode.responses[index];
      if (!resp) return;
      this.append("info", `You: ${resp.text}`);

      // support starting quests from dialogue responses
      if (resp.startQuest) {
        this.startQuest(resp.startQuest);
      }

      if (resp.item_required) {
        var hasItem = this.inventory.indexOf(resp.item_required) !== -1;
        if (!hasItem) {
          this.append("info", `You need ${resp.item_required} to proceed.`);
          return;
        }
      }

      if (resp.skill_check) {
        var result = window.skillCheck(resp.skill_check.skill, resp.skill_check.dc, this.player);
        var rollText = `${resp.skill_check.skill.toUpperCase()} check: d20 (${result.roll}) + ${result.mod} = ${result.total} vs DC ${result.dc}`;
        this.append(result.success ? "info" : "combat", rollText);
        var nextNode = result.success ? resp.nextNode : resp.failNode;
        if (!nextNode) {
          this.endDialogue();
          return;
        }
        this.moveDialogue(nextNode);
        return;
      }

      if (resp.nextNode) {
        this.moveDialogue(resp.nextNode);
      } else {
        this.endDialogue();
      }
    },
    moveDialogue(nodeId) {
      if (!this.currentNPC) return;
      var node = this.currentNPC.dialogueTree[nodeId];
      if (!node) {
        this.endDialogue();
        return;
      }
      this.currentDialogue.nodeId = nodeId;
      if (node.text) {
        this.append("narrative", node.text);
      }
      if (!node.responses || !node.responses.length) {
        this.append("info", "The conversation ends.");
      }
    },
    endDialogue() {
      this.currentDialogue = { npcId: null, nodeId: null };
      this.append("info", "Dialogue ended.");
    },
    showInventory() {
      const names = this.inventory.map((item) =>
        typeof item === "string" ? item : (item && item.name ? item.name : "Unknown item")
      );
      this.append("info", `Inventory: ${names.join(", ")}`);
      this.append("info", `Supplies: ${this.resources.rations} rations, ${this.resources.gold} gold.`);
    },
    whereAmI() {
      const loc = this.currentLocation ? this.currentLocation.name : "Unknown";
      this.append("info", `You are at ${loc}. Time: ${this.timeLabel}`);
      if (this.adjacentRoutes.length) {
        this.append(
          "info",
          `Nearby routes: ${this.adjacentRoutes
            .map((r) => `${r.destination ? r.destination.name : r.route.to} (${r.route.hours || 1}h)`)
            .join(", ")}`
        );
      }
    },
    gatherSupplies() {
      // Simple foraging action: costs time, chance to gain rations
      this.advanceTime(1);
      this.append("info", `You spend an hour gathering supplies. Time: ${this.timeLabel}`);
      const roll = Math.random();
      if (roll < 0.6) {
        const gain = roll < 0.2 ? 2 : 1;
        this.resources.rations += gain;
        this.append("info", `You find ${gain} ration${gain > 1 ? "s" : ""}.`);
      } else {
        this.append("info", "You find nothing useful.");
      }
      if (Math.random() < 0.1) {
        this.append("combat", "A minor encounter interrupts your foraging. (Encounter system placeholder)");
      }
    },
    buyRations(amount) {
      const locId = this.currentLocation ? this.currentLocation.id : null;
      const canBuy = locId === "protectors-enclave" || locId === "beached-leviathan";
      if (!canBuy) {
        this.append("info", "There is nowhere to buy supplies here.");
        return;
      }
      if (!this.isMarketOpen()) {
        this.append("info", "The market is closed. Try again during the day.");
        return;
      }
      const qty = Math.max(1, amount || 1);
      const cost = qty; // 1 gold per ration
      if (this.resources.gold < cost) {
        this.append("info", "You don't have enough gold.");
        return;
      }
      this.resources.gold -= cost;
      this.resources.rations += qty;
      this.append("info", `You buy ${qty} ration${qty > 1 ? "s" : ""} for ${cost} gold.`);
    },
    saveGame() {
      try {
        const saveData = {
          player: this.player,
          inventory: this.inventory,
          resources: this.resources,
          currentLocationId: this.currentLocationId,
          time: this.time,
          quests: this.quests,
          combat: this.combat,
          settings: this.settings
        };
        localStorage.setItem('neverwinterSave', JSON.stringify(saveData));
        this.append('info', 'Game saved successfully!');
        return true;
      } catch (e) {
        console.error('Save error:', e);
        this.append('info', 'Failed to save game.');
        return false;
      }
    },
    
    loadGame() {
      try {
        const saveData = localStorage.getItem('neverwinterSave');
        if (!saveData) {
          this.append('info', 'No saved game found.');
          return false;
        }
        
        const data = JSON.parse(saveData);
        
        // If we have a valid save state, use applySaveState
        if (this.applySaveState(data)) {
          this.append('info', 'Game loaded successfully!');
          this.describeLocation();
          return true;
        } else {
          this.append('info', 'Failed to load saved game.');
          return false;
        }
      } catch (e) {
        console.error('Load error:', e);
        this.append('info', 'Failed to load saved game. The save file might be corrupted.');
        return false;
      }
    },
    getSaveState() {
      return {
        player: this.player,
        inventory: this.inventory,
        resources: this.resources,
        time: this.time,
        currentLocationId: this.currentLocationId,
        currentDialogue: this.currentDialogue,
        gameLog: this.gameLog,
        quests: this.quests,
        combat: this.combat,
        settings: this.settings
      };
    },
    
    applySaveState(state) {
      if (!state || typeof state !== "object") return false;
      
      try {
        // Update player stats
        if (state.player) {
          Object.keys(state.player).forEach(key => {
            if (this.player.hasOwnProperty(key)) {
              this.player[key] = state.player[key];
            }
          });
        }
        
        // Update other properties
        this.inventory = Array.isArray(state.inventory) ? state.inventory : [];
        this.resources = { 
          gold: parseInt(state.resources?.gold) || 0, 
          rations: parseInt(state.resources?.rations) || 0, 
          fatigue: parseInt(state.resources?.fatigue) || 0 
        };
        
        if (state.currentLocationId) {
          this.currentLocationId = state.currentLocationId;
        }
        
        this.time = {
          day: parseInt(state.time?.day) || 1,
          hour: parseInt(state.time?.hour) || 8
        };
        
        this.quests = typeof state.quests === 'object' ? state.quests : {};
        this.combat = state.combat && typeof state.combat === 'object' ? state.combat : { inCombat: false };
        
        // Update settings
        if (state.settings) {
          this.settings = {
            ...this.settings,
            ...(state.settings.showTimestamps !== undefined ? { showTimestamps: state.settings.showTimestamps } : {}),
            ...(state.settings.compactLog !== undefined ? { compactLog: state.settings.compactLog } : {}),
            ...(state.settings.textSize ? { textSize: parseInt(state.settings.textSize) || 16 } : {})
          };
        }
        
        this.currentDialogue = state.currentDialogue || { npcId: null, nodeId: null };
        this.gameLog = Array.isArray(state.gameLog) ? state.gameLog : [];
        
        return true;
      } catch (e) {
        console.error('Error applying save state:', e);
        return false;
      }
    },
    
    exportSave() {
      try {
        this.saveText = JSON.stringify(this.getSaveState());
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(this.saveText).then(() => {
            this.append("info", "Save copied to clipboard.");
          }).catch(err => {
            console.error('Failed to copy to clipboard:', err);
            this.append("info", "Save exported. Copy the text to save it.");
          });
        } else {
          this.append("info", "Save exported. Copy the text to save it.");
        }
      } catch (e) {
        console.error('Export error:', e);
        this.append("info", "Failed to export save.");
      }
    },
    
    importSave() {
      try {
        if (!this.saveText) {
          this.append("info", "No save data to import.");
          return;
        }
        
        const state = JSON.parse(this.saveText);
        if (this.applySaveState(state)) {
          this.append("info", "Game imported successfully!");
          this.describeLocation();
        } else {
          this.append("info", "Failed to import game. The save data is invalid.");
        }
      } catch (e) {
        console.error('Import error:', e);
        this.append("info", "Failed to import game. The save data might be corrupted.");
      }
    },
    
    // Other methods...
    exportSave() {
      try {
        this.saveText = JSON.stringify(this.getSaveState());
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(this.saveText).then(() => {
            this.append("info", "Save copied to clipboard.");
          });
        } else {
          this.append("info", "Save generated. Copy from the box.");
        }
      } catch (e) {
        this.append("info", "Failed to export save.");
      }
    },
    importSave() {
      try {
        if (!this.saveText) {
          this.append("info", "Paste a save string first.");
          return;
        }
        const state = JSON.parse(this.saveText);
        if (this.applySaveState(state)) {
          this.append("info", "Save imported.");
        } else {
          this.append("info", "Save string invalid.");
        }
      } catch (e) {
        this.append("info", "Failed to import save.");
      }
    },
    submitCommand() {
      const raw = (this.userInput || "").trim();
      if (!raw) return;

      // Add command to log (preserve original casing)
      this.append("command", `> ${raw}`);
      this.userInput = "";

      // Try to handle with the enhanced command processor first
      if (this.processCommand(raw)) {
        return;
      }

      const normalized = raw.toLowerCase();
      const parts = normalized.split(/\s+/);
      const action = parts[0];
      const rest = parts.slice(1).join(" ");
      const args = parts.slice(1);

      if (action === "help") {
        this.append(
          "info",
          "Commands: move <location>, plan <location>, travel, look, talk <npc>, choose <number>, inventory, routes, map, where am i, gather, buy rations [n], save, load"
        );
        return;
      }

      if (action === "map") {
        this.showMap = !this.showMap;
        this.append("info", `Map ${this.showMap ? "shown" : "hidden"}.`);
        return;
      }

      if (action === "look") {
        this.describeLocation();
        return;
      }

      if (action === "talk") {
        if (!this.npcsInLocation.length) {
          this.append("info", "There is no one here to talk to.");
          return;
        }
        const npcName = rest.trim().toLowerCase();
        let npc = null;
        if (npcName) {
          npc = this.npcsInLocation.find(
            (n) => n.name.toLowerCase().includes(npcName) || n.id.toLowerCase().includes(npcName)
          );
        }
        if (!npc) {
          if (this.npcsInLocation.length === 1) {
            npc = this.npcsInLocation[0];
          } else {
            this.append(
              "info",
              "Please specify which NPC to talk to. Available NPCs: " + this.npcsInLocation.map((n) => n.name).join(", ")
            );
            return;
          }
        }
        this.startDialogue(npc.id);
        return;
      }

      if (action === "choose") {
        const idx = parseInt(parts[1], 10);
        if (isNaN(idx) || idx < 1) {
          this.append("info", "Choose which option? Example: choose 1");
          return;
        }
        this.chooseResponse(idx - 1);
        return;
      }

      if (["north", "south", "east", "west", "n", "s", "e", "w"].includes(action)) {
        const dirMap = {
          north: "n",
          n: "n",
          south: "s",
          s: "s",
          east: "e",
          e: "e",
          west: "w",
          w: "w",
        };
        this.moveDirection(dirMap[action]);
        return;
      }

      if (action === "move") {
        if (!rest) {
          this.append("info", "Move where?");
          return;
        }
        const loc = this.locations.find(
          (l) => l.name.toLowerCase() === rest.toLowerCase() || l.id.toLowerCase() === rest.toLowerCase()
        );
        if (!loc) {
          this.append("info", "Unknown location.");
          return;
        }
        this.travel(loc.id);
        return;
      }

      if (action === "plan") {
        if (!rest) {
          this.append("info", "Plan to where? Example: plan castle-never");
          return;
        }
        const loc = this.locations.find(
          (l) => l.name.toLowerCase() === rest.toLowerCase() || l.id.toLowerCase() === rest.toLowerCase()
        );
        if (!loc) {
          this.append("info", "Unknown location.");
          return;
        }
        this.planRoute(loc.id);
        return;
      }

      if (action === "travel") {
        if (!this.travelPreview) {
          this.append("info", "No route selected. Use plan <location> or choose a route from the list.");
          return;
        }
        if (this.travelPreview.planned) {
          this.executePlannedRoute();
          return;
        }
        if (this.travelPreview.route) {
          this.executeTravel(this.travelPreview.route);
          return;
        }
        this.append("info", "No valid route to travel.");
        return;
      }

      if (action === "inventory") {
        this.showInventory();
        return;
      }

      if (action === "routes") {
        if (!this.adjacentRoutes.length) {
          this.append("info", "No known routes from here.");
          return;
        }
        this.append(
          "info",
          `Routes: ${this.adjacentRoutes
            .map((r) => `${r.destination ? r.destination.name : r.route.to} (${r.route.hours || 1}h)`)
            .join(", ")}`
        );
        return;
      }

      if (action === "where") {
        if (rest.toLowerCase() === "am i" || rest.toLowerCase() === "ami") {
          this.whereAmI();
          return;
        }
      }

      if (action === "gather") {
        this.gatherSupplies();
        return;
      }

      if (action === "buy") {
        const tokens = rest.split(/\s+/);
        if (tokens[0] === "rations") {
          const qty = tokens.length > 1 ? parseInt(tokens[1], 10) : 1;
          this.buyRations(isNaN(qty) ? 1 : qty);
          return;
        }
      }

      if (action === "save") {
        this.saveGame();
        return;
      }

      if (action === "load") {
        this.loadGame();
        return;
      }

      if (action === "eat") {
        this.eat(rest || "rations");
        return;
      }

      if (action === "wait") {
        const hrs = parseInt(parts[1], 10);
        const h = isNaN(hrs) ? 1 : Math.max(1, hrs);
        this.advanceTime(h);
        this.append("info", `You wait ${h} hour${h > 1 ? "s" : ""}. Time: ${this.timeLabel}`);
        return;
      }

      this.append("info", "Unknown command. Type help.");
    },
  },
  mounted() {
    if (!this.currentLocationId && this.locations.length) {
      this.currentLocationId = this.locations[0].id;
    }
    if (this.currentLocation) {
      this.describeLocation();
    }
    // load persisted settings (if any)
    this.loadSettings();
    // load persisted quests (if any)
    this.loadQuests();
  },
});

// Export the app for the HTML module script to mount
export default app;
