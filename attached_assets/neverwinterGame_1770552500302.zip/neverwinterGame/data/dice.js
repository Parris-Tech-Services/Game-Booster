// Minimal dice and skill-check utilities used by the app
(function(window){
  window.skillCheck = function(skill, dc, player){
    const roll = Math.floor(Math.random()*20) + 1;
    const stat = (player && typeof player[skill] === 'number') ? player[skill] : 10;
    const mod = Math.floor((stat - 10) / 2);
    const total = roll + mod;
    return { roll: roll, mod: mod, total: total, dc: dc, success: total >= dc };
  };
})(window);
